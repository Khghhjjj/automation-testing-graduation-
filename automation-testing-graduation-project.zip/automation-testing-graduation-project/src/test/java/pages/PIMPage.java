package pages;

import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PIMPage extends BasePage {
    private final By employeeListTab = By.xpath("//a[normalize-space()='Employee List']");
    private final By addEmployeeTab = By.xpath("//a[normalize-space()='Add Employee']");
    private final By employeeNameInput = By.xpath(
            "//label[text()='Employee Name']/ancestor::div[contains(@class,'oxd-input-group')]//input");
    private final By searchButton = By.xpath("//button[normalize-space()='Search']");
    private final By resultRows = By.cssSelector(".oxd-table-body .oxd-table-card");
    private final By noRecordsMessage = By.xpath("//*[text()='No Records Found']");

    public PIMPage(WebDriver driver) {
        super(driver);
    }

    @Step("Go to Employee List")
    public PIMPage openEmployeeList() {
        log.info("Navigating to Employee List");
        click(employeeListTab);
        waitVisible(employeeNameInput);
        return this;
    }

    @Step("Go to Add Employee")
    public AddEmployeePage openAddEmployee() {
        log.info("Navigating to Add Employee");
        click(addEmployeeTab);
        return new AddEmployeePage(driver);
    }

    @Step("Search for employee '{0}'")
    public PIMPage searchEmployee(String name) {
        log.info("Searching for employee: {}", name);
        type(employeeNameInput, name);
        click(searchButton);
        waitForLoaderGone();
        return this;
    }

    @Step("Get the text of the results table")
    public String getResultsText() {
        waitVisible(resultRows);
        return driver.findElement(By.cssSelector(".oxd-table-body")).getText();
    }

    @Step("Check results table contains '{0}'")
    public boolean resultsContain(String text) {
        return getResultsText().contains(text);
    }

    @Step("Check the 'No Records Found' message")
    public boolean isNoRecordsFoundDisplayed() {
        return isDisplayed(noRecordsMessage);
    }
}
