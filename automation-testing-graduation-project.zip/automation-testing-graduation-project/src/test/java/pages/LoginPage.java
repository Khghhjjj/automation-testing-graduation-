package pages;

import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import utils.ConfigReader;

import java.util.List;

public class LoginPage extends BasePage {
    private final By usernameInput = By.name("username");
    private final By passwordInput = By.name("password");
    private final By loginButton = By.cssSelector("button[type='submit']");
    private final By errorMessage = By.cssSelector(".oxd-alert-content-text");
    private final By requiredMessages = By.cssSelector(".oxd-input-field-error-message");
    private final By footerText = By.cssSelector(".orangehrm-copyright-wrapper");
    private final By footerLink = By.xpath("//a[normalize-space()='OrangeHRM, Inc']");

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    @Step("Open the login page")
    public LoginPage open() {
        log.info("Opening login page");
        driver.get(ConfigReader.get("base.url") + "auth/login");
        waitVisible(usernameInput);
        return this;
    }

    @Step("Enter username '{0}' and password")
    public LoginPage enterCredentials(String username, String password) {
        log.info("Entering credentials for user: {}", username);
        if (!username.isEmpty()) type(usernameInput, username);
        if (!password.isEmpty()) type(passwordInput, password);
        return this;
    }

    @Step("Click the Login button")
    public void clickLogin() {
        log.info("Clicking Login");
        click(loginButton);
    }

    @Step("Login with username '{0}'")
    public DashboardPage login(String username, String password) {
        enterCredentials(username, password);
        clickLogin();
        return new DashboardPage(driver);
    }

    @Step("Read the error message")
    public String getErrorMessage() {
        return getText(errorMessage);
    }

    @Step("Count 'Required' validation messages")
    public int getRequiredMessagesCount() {
        try {
            wait.until(d -> d.findElements(requiredMessages).size() >= 2);
        } catch (TimeoutException ignored) {
        }
        List<WebElement> msgs = driver.findElements(requiredMessages);
        return (int) msgs.stream().filter(m -> m.getText().trim().equals("Required")).count();
    }

    @Step("Read the footer text")
    public String getFooterText() {
        return getText(footerText);
    }

    @Step("Click the 'OrangeHRM, Inc' footer link and switch to the new tab")
    public String clickFooterLinkAndGetNewTabUrl() {
        String original = driver.getWindowHandle();
        click(footerLink);
        wait.until(d -> d.getWindowHandles().size() > 1);
        for (String handle : driver.getWindowHandles()) {
            if (!handle.equals(original)) {
                driver.switchTo().window(handle);
                break;
            }
        }
        wait.until(d -> !d.getCurrentUrl().equals("about:blank"));
        return driver.getCurrentUrl();
    }
}
