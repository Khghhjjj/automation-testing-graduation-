package pages;

import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.stream.Collectors;

public class DashboardPage extends BasePage {
    private final By header = By.cssSelector(".oxd-topbar-header-breadcrumb h6");
    private final By sidebarItems = By.cssSelector(".oxd-main-menu-item--name");

    public DashboardPage(WebDriver driver) {
        super(driver);
    }

    @Step("Check the Dashboard header is displayed")
    public boolean isDashboardHeaderDisplayed() {
        return isDisplayed(header) && getText(header).equals("Dashboard");
    }

    @Step("Get sidebar menu items")
    public List<String> getSidebarItems() {
        waitAll(sidebarItems);
        return driver.findElements(sidebarItems).stream()
                .map(WebElement::getText)
                .map(String::trim)
                .collect(Collectors.toList());
    }

    @Step("Open the PIM module")
    public PIMPage openPIM() {
        log.info("Opening PIM module");
        click(By.xpath("//span[text()='PIM']"));
        return new PIMPage(driver);
    }

    @Step("Open the Admin module")
    public AdminPage openAdmin() {
        log.info("Opening Admin module");
        click(By.xpath("//span[text()='Admin']"));
        return new AdminPage(driver);
    }
}
