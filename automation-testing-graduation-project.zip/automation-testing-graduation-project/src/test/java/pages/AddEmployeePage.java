package pages;

import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AddEmployeePage extends BasePage {
    private final By firstName = By.name("firstName");
    private final By lastName = By.name("lastName");
    private final By saveButton = By.cssSelector("button[type='submit']");
    private final By firstNameError = By.xpath(
            "//input[@name='firstName']/ancestor::div[contains(@class,'oxd-input-group')]"
                    + "//span[contains(@class,'oxd-input-field-error-message')]");
    private final By personalDetailsHeader = By.xpath("//h6[text()='Personal Details']");

    public AddEmployeePage(WebDriver driver) {
        super(driver);
    }

    @Step("Check First Name and Last Name fields are displayed")
    public boolean areNameFieldsDisplayed() {
        return isDisplayed(firstName) && isDisplayed(lastName);
    }

    @Step("Enter first name '{0}'")
    public AddEmployeePage enterFirstName(String value) {
        type(firstName, value);
        return this;
    }

    @Step("Enter last name '{0}'")
    public AddEmployeePage enterLastName(String value) {
        type(lastName, value);
        return this;
    }

    @Step("Click Save")
    public AddEmployeePage clickSave() {
        log.info("Clicking Save");
        click(saveButton);
        return this;
    }

    @Step("Read First Name validation error")
    public String getFirstNameError() {
        return getText(firstNameError);
    }

    @Step("Check the Personal Details page is displayed")
    public boolean isPersonalDetailsDisplayed() {
        waitForUrlContains("/pim/viewPersonalDetails");
        return isDisplayed(personalDetailsHeader);
    }
}
