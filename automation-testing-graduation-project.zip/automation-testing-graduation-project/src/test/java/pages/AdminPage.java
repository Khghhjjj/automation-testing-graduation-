package pages;

import io.qameta.allure.Step;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AdminPage extends BasePage {
    private final By userManagementMenu = By.xpath("//span[normalize-space()='User Management']");
    private final By usersOption = By.xpath("//a[normalize-space()='Users']");
    private final By addButton = By.xpath("//button[normalize-space()='Add']");

    public AdminPage(WebDriver driver) {
        super(driver);
    }

    @Step("Navigate to User Management > Users")
    public AdminPage openUsers() {
        log.info("Navigating to User Management > Users");
        click(userManagementMenu);
        click(usersOption);
        waitForUrlContains("/admin/viewSystemUsers");
        return this;
    }

    @Step("Click Add")
    public AdminPage clickAdd() {
        click(addButton);
        waitForUrlContains("/admin/saveSystemUser");
        return this;
    }

    @Step("Check form field '{0}' is displayed")
    public boolean isFieldLabelDisplayed(String label) {
        return isDisplayed(By.xpath("//form//label[normalize-space()='" + label + "']"));
    }
}
