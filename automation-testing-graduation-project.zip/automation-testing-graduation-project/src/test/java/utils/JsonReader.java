package utils;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;

public class JsonReader {
    private static final JsonObject root;

    static {
        try (InputStream in = JsonReader.class.getClassLoader().getResourceAsStream("testdata.json");
             Reader reader = new InputStreamReader(in, StandardCharsets.UTF_8)) {
            root = JsonParser.parseReader(reader).getAsJsonObject();
        } catch (Exception e) {
            throw new RuntimeException("Failed to load testdata.json", e);
        }
    }

    /** Returns an array of JSON objects as Object[][] where each row holds the values of the given keys. */
    public static Object[][] getData(String arrayName, String... keys) {
        JsonArray array = root.getAsJsonArray(arrayName);
        Object[][] data = new Object[array.size()][keys.length];
        for (int i = 0; i < array.size(); i++) {
            JsonObject obj = array.get(i).getAsJsonObject();
            for (int j = 0; j < keys.length; j++) {
                data[i][j] = obj.get(keys[j]).getAsString();
            }
        }
        return data;
    }

    public static String[] getStringArray(String arrayName) {
        JsonArray array = root.getAsJsonArray(arrayName);
        String[] result = new String[array.size()];
        int i = 0;
        for (JsonElement e : array) {
            result[i++] = e.getAsString();
        }
        return result;
    }
}
