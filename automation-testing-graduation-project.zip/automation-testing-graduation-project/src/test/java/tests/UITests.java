package tests;

import base.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.DashboardPage;
import pages.LoginPage;
import utils.JsonReader;

import java.util.Arrays;
import java.util.List;

@Epic("OrangeHRM")
@Feature("UI")
public class UITests extends BaseTest {

    @Test(description = "TC10: Verify the OrangeHRM footer/branding link")
    @Description("Verify footer text and that the footer link opens orangehrm.com in a new tab")
    public void testFooterBrandingLink() {
        LoginPage login = openLoginPage();
        Assert.assertTrue(login.getFooterText().contains("OrangeHRM, Inc"), "Footer should contain 'OrangeHRM, Inc'");
        String newTabUrl = login.clickFooterLinkAndGetNewTabUrl();
        Assert.assertTrue(newTabUrl.contains("orangehrm.com"), "New tab URL should contain orangehrm.com but was: " + newTabUrl);
    }

    @Test(description = "TC11: Verify sidebar menu UI")
    @Description("Login and verify the sidebar contains the expected menu items")
    public void testSidebarMenu() {
        DashboardPage dashboard = loginAsAdmin();
        List<String> expected = Arrays.asList(JsonReader.getStringArray("sidebarItems"));
        List<String> actual = dashboard.getSidebarItems();
        Assert.assertTrue(actual.containsAll(expected),
                "Sidebar should contain " + expected + " but was " + actual);
    }
}
