package tests;

import base.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.DashboardPage;
import pages.LoginPage;
import utils.JsonReader;

@Epic("OrangeHRM")
@Feature("Login")
public class LoginTests extends BaseTest {

    @DataProvider(name = "validLogins")
    public Object[][] validLogins() {
        return JsonReader.getData("validLogins", "username", "password");
    }

    @DataProvider(name = "invalidLogins")
    public Object[][] invalidLogins() {
        return JsonReader.getData("invalidLogins", "username", "password");
    }

    @Test(dataProvider = "validLogins", description = "TC1: Login with valid credentials")
    @Description("Login with valid credentials and verify the Dashboard is displayed")
    public void testLoginWithValidCredentials(String username, String password) {
        DashboardPage dashboard = openLoginPage().login(username, password);
        dashboard.waitForUrlContains("/dashboard/index");
        Assert.assertTrue(dashboard.getCurrentUrl().contains("/dashboard/index"), "URL should contain /dashboard/index");
        Assert.assertTrue(dashboard.isDashboardHeaderDisplayed(), "Dashboard header should be displayed");
    }

    @Test(dataProvider = "invalidLogins", description = "TC2: Login with invalid credentials")
    @Description("Login with invalid credentials and verify the error message")
    public void testLoginWithInvalidCredentials(String username, String password) {
        LoginPage login = openLoginPage();
        login.login(username, password);
        Assert.assertEquals(login.getErrorMessage(), "Invalid credentials");
    }

    @Test(description = "TC3: Login with empty fields")
    @Description("Click Login with empty fields and verify both 'Required' messages")
    public void testLoginWithEmptyFields() {
        LoginPage login = openLoginPage();
        login.clickLogin();
        Assert.assertEquals(login.getRequiredMessagesCount(), 2, "Both fields should show 'Required'");
    }
}
