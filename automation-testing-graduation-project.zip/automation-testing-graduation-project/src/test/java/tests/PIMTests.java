package tests;

import base.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.AddEmployeePage;
import pages.PIMPage;
import utils.JsonReader;

@Epic("OrangeHRM")
@Feature("PIM")
public class PIMTests extends BaseTest {

    @DataProvider(name = "knownEmployees")
    public Object[][] knownEmployees() {
        return JsonReader.getData("knownEmployees", "name");
    }

    @DataProvider(name = "invalidEmployees")
    public Object[][] invalidEmployees() {
        return JsonReader.getData("invalidEmployees", "name");
    }

    @DataProvider(name = "emptyFirstName")
    public Object[][] emptyFirstName() {
        return JsonReader.getData("emptyFirstName", "lastName");
    }

    @DataProvider(name = "newEmployees")
    public Object[][] newEmployees() {
        return JsonReader.getData("newEmployees", "firstName", "lastName");
    }

    @Test(dataProvider = "knownEmployees", description = "TC4: Search for an employee")
    @Description("Search for a known employee in PIM and verify the results table")
    public void testSearchEmployee(String name) {
        PIMPage pim = loginAsAdmin().openPIM().openEmployeeList();
        pim.searchEmployee(name);
        Assert.assertTrue(pim.resultsContain(name), "Results should contain the searched employee: " + name);
    }

    @Test(dataProvider = "invalidEmployees", description = "TC5: Search for a non-existing employee")
    @Description("Search for an invalid name and verify 'No Records Found'")
    public void testSearchNonExistingEmployee(String name) {
        PIMPage pim = loginAsAdmin().openPIM().openEmployeeList();
        pim.searchEmployee(name);
        Assert.assertTrue(pim.isNoRecordsFoundDisplayed(), "'No Records Found' should be displayed");
    }

    @Test(description = "TC6: Open Add Employee page")
    @Description("Open the Add Employee page and verify URL and name fields")
    public void testOpenAddEmployeePage() {
        AddEmployeePage add = loginAsAdmin().openPIM().openAddEmployee();
        add.waitForUrlContains("/pim/addEmployee");
        Assert.assertTrue(add.getCurrentUrl().contains("/pim/addEmployee"));
        Assert.assertTrue(add.areNameFieldsDisplayed(), "First Name and Last Name fields should be displayed");
    }

    @Test(dataProvider = "emptyFirstName", description = "TC7: Add employee with empty required field")
    @Description("Enter only Last Name and verify First Name shows 'Required'")
    public void testAddEmployeeWithEmptyFirstName(String lastName) {
        AddEmployeePage add = loginAsAdmin().openPIM().openAddEmployee();
        add.enterLastName(lastName).clickSave();
        Assert.assertEquals(add.getFirstNameError(), "Required");
    }

    @Test(dataProvider = "newEmployees", description = "TC8: End-to-end add a new employee")
    @Description("Add a new employee, verify Personal Details, then find the employee in the list")
    public void testAddNewEmployeeEndToEnd(String firstName, String lastName) {
        // unique first name so the search result is unambiguous
        String uniqueFirst = firstName + System.currentTimeMillis() % 100000;
        PIMPage pim = loginAsAdmin().openPIM();
        AddEmployeePage add = pim.openAddEmployee();
        add.enterFirstName(uniqueFirst).enterLastName(lastName).clickSave();
        Assert.assertTrue(add.isPersonalDetailsDisplayed(), "Personal Details page should open");

        pim.openEmployeeList().searchEmployee(uniqueFirst);
        Assert.assertTrue(pim.resultsContain(uniqueFirst), "New employee should appear in the results");
    }
}
