package tests;

import base.BaseTest;
import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.AdminPage;

@Epic("OrangeHRM")
@Feature("Admin")
public class AdminTests extends BaseTest {

    @Test(description = "TC9: Verify Admin > Add User page")
    @Description("Open Add User form and verify its fields")
    public void testAddUserFormFields() {
        AdminPage admin = loginAsAdmin().openAdmin().openUsers().clickAdd();
        for (String field : new String[]{"User Role", "Employee Name", "Username", "Password"}) {
            Assert.assertTrue(admin.isFieldLabelDisplayed(field), "Field should be displayed: " + field);
        }
    }
}
