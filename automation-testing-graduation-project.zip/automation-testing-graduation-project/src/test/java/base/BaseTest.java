package base;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import pages.DashboardPage;
import pages.LoginPage;
import utils.ConfigReader;

public class BaseTest {
    protected static final Logger log = LogManager.getLogger(BaseTest.class);
    protected WebDriver driver;

    @BeforeMethod(alwaysRun = true)
    public void setUp() {
        DriverManager.initDriver(ConfigReader.get("browser"));
        driver = DriverManager.getDriver();
        log.info("Browser started: {}", ConfigReader.get("browser"));
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown() {
        DriverManager.quitDriver();
        log.info("Browser closed");
    }

    protected LoginPage openLoginPage() {
        return new LoginPage(driver).open();
    }

    protected DashboardPage loginAsAdmin() {
        return openLoginPage().login("Admin", "admin123");
    }
}
