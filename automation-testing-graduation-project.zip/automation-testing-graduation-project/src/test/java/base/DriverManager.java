package base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import utils.ConfigReader;

public class DriverManager {
    // Each thread gets its own independent WebDriver (required for parallel runs)
    private static final ThreadLocal<WebDriver> driver = new ThreadLocal<>();

    public static void initDriver(String browser) {
        boolean headless = Boolean.parseBoolean(System.getProperty("headless", ConfigReader.get("headless")));
        WebDriver d;
        switch (browser.toLowerCase()) {
            case "firefox":
                FirefoxOptions ff = new FirefoxOptions();
                if (headless) ff.addArguments("-headless");
                d = new FirefoxDriver(ff);
                break;
            case "edge":
                EdgeOptions eo = new EdgeOptions();
                if (headless) eo.addArguments("--headless=new");
                d = new EdgeDriver(eo);
                break;
            default:
                ChromeOptions co = new ChromeOptions();
                if (headless) co.addArguments("--headless=new");
                co.addArguments("--window-size=1920,1080", "--disable-notifications");
                d = new ChromeDriver(co);
        }
        d.manage().window().maximize();
        driver.set(d);
    }

    public static WebDriver getDriver() {
        return driver.get();
    }

    public static void quitDriver() {
        WebDriver d = driver.get();
        if (d != null) {
            d.quit();
            driver.remove();
        }
    }
}
