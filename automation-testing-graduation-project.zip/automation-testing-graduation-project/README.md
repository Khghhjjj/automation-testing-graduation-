# OrangeHRM Automation Testing – Graduation Project

Selenium WebDriver + TestNG + Page Object Model, with data-driven tests (JSON + Gson),
parallel execution (`parallel="tests"`, `ThreadLocal<WebDriver>`), Log4j2, retry analyzer and Allure reporting.

Site under test: https://opensource-demo.orangehrmlive.com/web/index.php/auth/login (Admin / admin123)

## Requirements
- JDK 17+
- Maven 3.8+
- Google Chrome (Selenium Manager downloads the driver automatically)
- Allure commandline (`npm i -g allure-commandline` or from https://allurereport.org)

## Run
```
mvn clean test
allure generate allure-results --clean -o allure-report
allure open allure-report
```
Headless: `mvn test -Dheadless=true`

## Structure
- `src/test/java/base` – DriverManager (ThreadLocal) and BaseTest
- `src/test/java/pages` – Page Objects
- `src/test/java/tests` – Test classes (TC1–TC11)
- `src/test/java/utils` – ConfigReader, JsonReader, RetryAnalyzer, TestListener
- `src/test/resources` – config.properties, testdata.json, log4j2.xml
- `testng.xml` – parallel suite config
